const MODEL = '@cf/meta/llama-3.3-70b-instruct-fp8-fast';
const ORIGIN = 'https://grandslamco.com';
const SYSTEM = `You are the official Grand Slam Co. website booking agent for a Saskatoon, Saskatchewan service company.
You are a polished, warm, concise customer-service professional. Never say you are a bot unless asked; if asked, say you are Grand Slam Co.'s AI booking assistant. Never claim a human is typing.
Services include: car detailing, house cleaning, move-out/move-in cleaning, moving help, furniture assembly, pressure washing, and hotel/motel property revamp.
Your job is to understand what the visitor wants, answer basic questions, collect only information needed to prepare a booking, and guide them to the booking form. Do not invent prices, availability, policies, or guarantees. If a price or availability is not in the conversation, say the team will confirm it.
For booking preparation, try to collect: service, address/area, home size when relevant to house cleaning, preferred date, preferred time window, customer name, phone, and useful job details. Do not demand every field before being helpful. If the visitor is just asking a question, answer naturally instead of forcing a booking.
Use Canadian/Saskatchewan wording and CAD when discussing money.
Keep replies short (usually 1-3 paragraphs or a few bullets). Ask one or two useful questions at a time.
Always return valid JSON with exactly two top-level keys: reply (string) and booking (object). booking must contain service, address, size, date, time, name, phone, details. Use empty strings for unknown fields. Never put markdown code fences around the JSON.`;

function corsHeaders(origin) {
  const allowed = origin === ORIGIN || origin === 'https://www.grandslamco.com' ? origin : ORIGIN;
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Vary': 'Origin',
    'Content-Type': 'application/json; charset=utf-8'
  };
}

function json(data, status, origin) {
  return new Response(JSON.stringify(data), { status, headers: corsHeaders(origin) });
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || ORIGIN;
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: corsHeaders(origin) });
    const url = new URL(request.url);
    if (url.pathname !== '/api/ai' || request.method !== 'POST') return json({ error: 'Not found' }, 404, origin);

    try {
      const body = await request.json();
      const messages = Array.isArray(body.messages) ? body.messages.slice(-14) : [];
      const clean = messages.map(m => ({
        role: m.role === 'assistant' ? 'assistant' : 'user',
        content: String(m.content || '').slice(0, 3000)
      }));
      if (!clean.length) return json({ error: 'No message supplied.' }, 400, origin);

      const result = await env.AI.run(MODEL, {
        messages: [{ role: 'system', content: SYSTEM }, ...clean],
        response_format: { type: 'json_object' },
        temperature: 0.35,
        max_tokens: 500
      });

      let text = result?.response || result?.result?.response || '';
      let parsed;
      try { parsed = typeof text === 'string' ? JSON.parse(text) : text; } catch (_) {}
      if (!parsed || typeof parsed.reply !== 'string') {
        parsed = { reply: String(text || 'I can help you with that. What service are you looking for?'), booking: {} };
      }
      const b = parsed.booking || {};
      parsed.booking = {
        service: String(b.service || ''), address: String(b.address || ''), size: String(b.size || ''),
        date: String(b.date || ''), time: String(b.time || ''), name: String(b.name || ''),
        phone: String(b.phone || ''), details: String(b.details || '')
      };
      return json(parsed, 200, origin);
    } catch (e) {
      return json({ error: 'The booking assistant is temporarily unavailable. Please call Grand Slam Co. at (306) 880-4618.' }, 500, origin);
    }
  }
};
