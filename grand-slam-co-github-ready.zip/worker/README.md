# Grand Slam Co AI Worker

This folder is the separate backend Worker for the Grand Slam Co AI booking agent.

Deploy independently from the `website/` folder. Do not configure Cloudflare Pages to build this directory.

Use Cloudflare Workers/Wrangler and keep credentials/API keys in secrets, not source control.
