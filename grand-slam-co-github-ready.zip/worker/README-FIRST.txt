GRAND SLAM CO — AI BOOKING WORKER
=================================

THIS ZIP IS ONLY THE AI BACKEND WORKER.
It does NOT contain the website pages or website images.

OPTION A — EASIEST DEPLOYMENT WITH WRANGLER
-------------------------------------------
1. Install Node.js if you do not already have it.
2. Open Terminal / PowerShell in this folder.
3. Run:

   npx wrangler login

4. Then run:

   npx wrangler deploy

5. Cloudflare will deploy the Worker named:

   grand-slam-ai-agent

The wrangler.toml already includes the Workers AI binding.

OPTION B — CLOUDFLARE DASHBOARD
--------------------------------
If you prefer the dashboard, create a Worker named:
   grand-slam-ai-agent

Upload/paste ai-agent-worker.js as the Worker code, then configure the
Workers AI binding named:
   AI

The AI model used by the code is:
   @cf/meta/llama-3.3-70b-instruct-fp8-fast

ROUTE FOR THE WEBSITE
---------------------
After the Worker is deployed, add a Worker Route in Cloudflare:

   grandslamco.com/api/ai*

The Pages website stays separate and serves normal website pages.
Only /api/ai is handled by this Worker.

IMPORTANT
---------
Do not put this Worker code inside the Pages upload.
Do not add a Pages functions/ directory.
Keep the website and AI Worker as two separate deployments.

TEST
----
The website's AI assistant should load normally. When a visitor sends a
message, the browser calls /api/ai and Cloudflare routes that request to this
Worker.
