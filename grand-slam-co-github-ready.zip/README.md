# Grand Slam Co

GitHub source for the Grand Slam Co website and AI booking Worker.

## Structure

- `website/` — static Grand Slam Co website. Connect this folder to Cloudflare Pages.
- `worker/` — separate Cloudflare Worker for the AI booking agent.

## Cloudflare Pages

- Production branch: `main`
- Root directory: `website`
- Build command: leave blank
- Deploy command: leave blank
- Preview command: leave blank

Connect the existing `grandslamco.com` domain to the Pages project after confirming the deployment works. Keep the current production Worker until the Pages version has been verified.

## AI Worker

The AI Worker is intentionally separate from Pages. Deploy `worker/` as the `grand-slam-ai-agent` Worker using Wrangler/GitHub Actions. Never put API keys in this repository; use Cloudflare/GitHub secrets.
