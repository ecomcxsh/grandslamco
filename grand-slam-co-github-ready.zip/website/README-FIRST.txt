GRAND SLAM CO — CLOUDFLARE PAGES WEBSITE
=========================================

THIS ZIP IS ONLY THE WEBSITE.
The AI booking backend is a separate Cloudflare Worker.

FASTEST DEPLOYMENT (Cloudflare Pages)
--------------------------------------
1. Log in to Cloudflare.
2. Go to Workers & Pages.
3. Choose Create application / Pages.
4. Choose Direct Upload (not Workers).
5. Create a new Pages project, for example:
      grandslamco-site
6. Upload this ZIP as the deployment asset.
7. Deploy.
8. Open the Pages *.pages.dev address and test the site.

USE THE CUSTOM DOMAIN
---------------------
After the Pages site works:
1. Open the Pages project.
2. Go to Custom domains.
3. Add:
      grandslamco.com
4. Also add:
      www.grandslamco.com
   if you want the www version.
5. Follow Cloudflare's DNS prompts.

IMPORTANT — EXISTING WORKER
---------------------------
Your current live website has previously been served by the Worker named:
      grandslamco

Before making grandslamco.com live on Pages, make sure the old website Worker
is no longer handling the catch-all website route. Do NOT delete it until the
new Pages site has been tested. The AI Worker can remain separate.

AI BOOKING AGENT
----------------
The website calls:
      POST /api/ai

That endpoint is provided by the separate Worker package:
      grand-slam-co-ai-worker-deployment-clean.zip

Deploy that Worker separately, then add the Worker route:
      grandslamco.com/api/ai*

The AI route should be more specific than the normal Pages website route.

WHAT IS INCLUDED
----------------
- Grand Slam Co website pages
- Premium Grand Slam Detailing pages
- Booking page
- CRM / Crew / Portal pages
- CSS and image assets
- robots.txt and sitemap.xml
- Firebase client configuration used by the site

WHAT IS NOT INCLUDED
--------------------
- AI Worker backend
- Cloudflare Worker code
- Lead-generator Worker backend

Those are intentionally separated so website updates and backend updates can
be deployed independently.
